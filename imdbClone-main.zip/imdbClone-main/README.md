# imdbClone
IMDB Clone made using the OMDB API

- Git Repository link: https://github.com/utkarshsingh341/imdbClone
- Video link: https://youtu.be/anHVWdGtDqQ
- Hosted link: https://utkarshsingh341.github.io/imdbClone/
